import * as admin from 'firebase-admin';
import { FieldValue, getFirestore } from 'firebase-admin/firestore';
import { onDocumentDeleted } from 'firebase-functions/v2/firestore';
import { onSchedule } from 'firebase-functions/v2/scheduler';

admin.initializeApp();

const DATABASE_ID = 'ai-studio-7e129900-fed6-4ad2-bf99-cc024935a3b6';

type ExpiryStatus = 'Active' | 'Expiring Soon' | 'Expired';

function computeExpiryStatus(
  expiryDateIso: string,
  reminderDaysBefore: number,
  referenceDate: Date = new Date()
): ExpiryStatus {
  const [year, month, day] = expiryDateIso.split('-').map(Number);
  const expiryUtcMidnight = Date.UTC(year, month - 1, day);
  const todayUtcMidnight = Date.UTC(
    referenceDate.getUTCFullYear(),
    referenceDate.getUTCMonth(),
    referenceDate.getUTCDate()
  );
  const diffDays = Math.floor((expiryUtcMidnight - todayUtcMidnight) / (1000 * 60 * 60 * 24));

  if (diffDays < 0) {
    return 'Expired';
  }
  if (diffDays <= reminderDaysBefore) {
    return 'Expiring Soon';
  }
  return 'Active';
}

/**
 * Scheduled daily Cloud Function (00:05 UTC) that recalculates document expiry statuses
 * across the Firestore database so status fields stay synchronized even when users are offline.
 */
export const syncDailyDocumentStatuses = onSchedule(
  {
    schedule: '5 0 * * *',
    timeZone: 'UTC',
  },
  async () => {
    const db = getFirestore(DATABASE_ID);

    const snapshot = await db.collection('documents').get();
    const batch = db.batch();
    let updatedCount = 0;

    for (const docSnap of snapshot.docs) {
      const data = docSnap.data();
      if (typeof data.expiryDate !== 'string') continue;

      const leadDays =
        typeof data.reminderDaysBefore === 'number' ? data.reminderDaysBefore : 30;
      const computedStatus = computeExpiryStatus(data.expiryDate, leadDays);

      if (data.status !== computedStatus) {
        batch.update(docSnap.ref, {
          status: computedStatus,
          reminderDismissed: computedStatus === 'Active' ? false : Boolean(data.reminderDismissed),
          updatedAt: FieldValue.serverTimestamp(),
        });
        updatedCount += 1;
      }
    }

    if (updatedCount > 0) {
      await batch.commit();
    }
  }
);

/**
 * Firestore trigger: removes the corresponding binary file from Firebase Storage
 * whenever a document metadata record is deleted.
 */
export const cleanupStorageOnDocumentDelete = onDocumentDeleted(
  {
    document: 'documents/{documentId}',
    database: DATABASE_ID,
  },
  async (event) => {
    const deletedData = event.data?.data();
    const storagePath = deletedData?.storagePath;
    if (typeof storagePath !== 'string' || !storagePath.startsWith('users/')) {
      return;
    }

    try {
      await admin.storage().bucket().file(storagePath).delete();
    } catch (error: unknown) {
      const errCode = (error as { code?: number })?.code;
      if (errCode !== 404) {
        console.error('Failed to delete Storage object on document removal:', error);
      }
    }
  }
);
